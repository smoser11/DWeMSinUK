#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL

#' Population network
#'
#'
#' @format A list containing two elements:
#' \describe{
#' \item{\code{traits}}{a dataframe of 2000 rows and 4 columns }
#' \item{\code{adj.mat}}{an adjacency matrix}
#' }
"pop.network"
