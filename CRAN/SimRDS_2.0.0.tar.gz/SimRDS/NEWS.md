# SimRDS 2.0.0

* Initial CRAN submission.
