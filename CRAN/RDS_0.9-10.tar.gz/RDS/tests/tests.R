

library(testthat)
library(RDS)

test_check("RDS")
