
Unfortunately, the Dataverse does not yet support replication code that
has a directory structure. In order to get around this, the replication materials
are double-zipped. So please download the .zip archive, unzip it, and then unzip
the resulting file.
